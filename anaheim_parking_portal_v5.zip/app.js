
let CFG=null, SPOTS=[], selected=null;

// nav
const screens=['reserve','pay','receipt'];
const navLinks=document.querySelectorAll('nav a[data-nav]');
function go(id){screens.forEach(s=>document.getElementById(s).classList.remove('visible'));document.getElementById(id).classList.add('visible');navLinks.forEach(a=>a.classList.remove('active'));document.querySelector(`nav a[data-nav="${id}"]`)?.classList.add('active');window.scrollTo(0,0);}
navLinks.forEach(a=>a.addEventListener('click',()=>go(a.dataset.nav)));

async function load(){
  CFG=await (await fetch('config.json')).json();
  SPOTS=await (await fetch('spots.json')).json();
  document.getElementById('logo').textContent=CFG.logoText||'AH';
  document.getElementById('hotelName').textContent=CFG.hotelName||'The Anaheim Hotel';
  document.getElementById('tagline').textContent=CFG.tagline||'';
  buildMap();
  updateEstimate();
}
load();

// Reserve screen elements
const mapEl=document.getElementById('map');
const selSpaceEl=document.getElementById('selSpace');
const estTotalEl=document.getElementById('estTotal');
const toPayBtn=document.getElementById('toPay');
const visitorTypeEl=document.getElementById('visitorType');
const durationEl=document.getElementById('duration');
const isEVEl=document.getElementById('isEV');
const chargingCostEl=document.getElementById('chargingCost');
const plateEl=document.getElementById('plate');

function buildMap(){
  mapEl.innerHTML='';
  SPOTS.forEach((s,i)=>{
    const cell=document.createElement('div');
    cell.className='cell';
    cell.textContent=s.id;
    cell.addEventListener('click',()=>{ selected=s; highlight(i); updateEstimate(); });
    mapEl.appendChild(cell);
  });
}
function highlight(idx){
  [...mapEl.children].forEach((c,i)=>c.classList.toggle('selected', i===idx));
  selSpaceEl.textContent=selected?.id || '—';
  toPayBtn.disabled = !(selected && plateEl.value.trim());
}

function hourCharge(){
  const base = (visitorTypeEl.value==='Staff') ? 0 : CFG.pricing.hourly;
  const isEV = isEVEl.value==='yes';
  const hourly = isEV && CFG.pricing.ev_half_off ? base/2 : base;
  return hourly;
}
function computeTotal(){
  const hours = Math.max(1, parseInt(durationEl.value||'1', 10));
  const hourly = hourCharge();
  let parking = hours * hourly;
  if (parking > CFG.pricing.max && visitorTypeEl.value!=='Staff') parking = CFG.pricing.max;
  const charging = Number(chargingCostEl.value || 0);
  const total = (visitorTypeEl.value==='Staff') ? 0 : (parking + charging);
  return {hours, hourly, parking, charging, total};
}
function updateEstimate(){
  const {total} = computeTotal();
  estTotalEl.textContent = `$${total.toFixed(2)}`;
  toPayBtn.disabled = !(selected && plateEl.value.trim());
}
[visitorTypeEl, durationEl, isEVEl, chargingCostEl, plateEl].forEach(el=>el.addEventListener('input', ()=>{updateEstimate(); if(selected) toPayBtn.disabled = !(selected && plateEl.value.trim());}));

document.getElementById('scanLPR').addEventListener('click', ()=>{
  // Demo: "scan" fills a plausible plate
  plateEl.value = '7RL' + Math.floor(1000 + Math.random()*8999);
  updateEstimate();
});

// Pay screen
const confSpace=document.getElementById('confSpace');
const confVisitor=document.getElementById('confVisitor');
const confDuration=document.getElementById('confDuration');
const confHourly=document.getElementById('confHourly');
const confEvDisc=document.getElementById('confEvDisc');
const confCharging=document.getElementById('confCharging');
const confTotal=document.getElementById('confTotal');
const emailEl=document.getElementById('email');
const smsEl=document.getElementById('sms');

toPayBtn.addEventListener('click', ()=>{
  const {hours, hourly, parking, charging, total} = computeTotal();
  confSpace.textContent = selected.id;
  confVisitor.textContent = visitorTypeEl.value;
  confDuration.textContent = `${hours} hour(s)`;
  confHourly.textContent = `$${hourly.toFixed(2)}/hr`;
  const evDisc = (isEVEl.value==='yes' && CFG.pricing.ev_half_off && visitorTypeEl.value!=='Staff') ? '50% applied' : '—';
  confEvDisc.textContent = evDisc;
  confCharging.textContent = `$${Number(charging).toFixed(2)}`;
  confTotal.textContent = `$${total.toFixed(2)}`;
  go('pay');
});

function finalize(){
  const {hours, hourly, parking, charging, total} = computeTotal();
  const now = new Date();
  const start = now.toISOString();
  const end = new Date(now.getTime() + hours*3600*1000).toISOString();
  const exitCode = String(Math.floor(1000+Math.random()*9000));

  // Save reservation
  const record = {
    code:'AH-'+Math.random().toString(36).slice(2,8).toUpperCase(),
    spotId:selected.id,
    visitorType: visitorTypeEl.value,
    plate: (plateEl.value||'').toUpperCase(),
    isEV: isEVEl.value==='yes',
    chargingCost: Number(charging).toFixed(2),
    hourly, parking: Number(parking).toFixed(2), total: Number(total).toFixed(2),
    start, end, exitCode
  };
  const data = JSON.parse(localStorage.getItem('reservations')||'[]');
  data.push(record); localStorage.setItem('reservations', JSON.stringify(data));

  // Fill receipt
  document.getElementById('rPlate').textContent = record.plate || '—';
  document.getElementById('rSpace').textContent = `Space ${record.spotId}`;
  document.getElementById('rDuration').textContent = `${hours} hour(s)`;
  document.getElementById('rAmount').textContent = `$${Number(total).toFixed(2)}`;
  document.getElementById('exitCode').textContent = exitCode;

  go('receipt');
}

document.getElementById('payNow').addEventListener('click', finalize);
document.getElementById('applePay').addEventListener('click', finalize);
document.getElementById('gPay').addEventListener('click', finalize);

document.getElementById('sendEmail').addEventListener('click', ()=>{
  const to = emailEl.value || '(no email)';
  alert('Email sent to ' + to + ' (demo)');
});
document.getElementById('sendSMS').addEventListener('click', ()=>{
  const to = smsEl.value || '(no phone)';
  alert('SMS sent to ' + to + ' (demo)');
});
document.getElementById('done').addEventListener('click', ()=>go('reserve'));
